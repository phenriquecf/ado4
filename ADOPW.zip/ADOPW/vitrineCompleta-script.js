function carregarDadosCliente() {
    var cliente = JSON.parse(localStorage.getItem('clienteLogado'));
    if (cliente) {
        document.getElementById('nomeCliente').textContent = cliente.nomeCliente;
        document.getElementById('avatarCliente').src = cliente.avatarCliente;
    } else {
        window.location.href = 'login.html';
    }
}

function adicionarAoCarrinho(idProduto) {
    var quantidade = prompt('Digite a quantidade desejada:');
    quantidade = parseInt(quantidade);

    if (!quantidade || quantidade <= 0) {
        alert('Por favor, insira uma quantidade válida.');
        return;
    }

    var produtos = obterProdutos();
    var carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];

    var produtoSelecionado = produtos.find(function(produto) {
        return produto.idProduto === idProduto;
    });

    if (!produtoSelecionado) {
        alert('Produto não encontrado.');
        return;
    }

    if (quantidade > produtoSelecionado.qtdEstoque) {
        alert('Desculpe, não há estoque suficiente para essa quantidade.');
        return;
    }

    var itemCarrinho = carrinho.find(function(item) {
        return item.idProduto === idProduto;
    });

    if (itemCarrinho) {
        itemCarrinho.quantidade += quantidade;
    } else {
        carrinho.push({
            idProduto: produtoSelecionado.idProduto,
            nome: produtoSelecionado.nome,
            valorUnitario: produtoSelecionado.valorUnitario,
            quantidade: quantidade
        });
    }

    localStorage.setItem('carrinho', JSON.stringify(carrinho));

    alert('Produto adicionado ao carrinho com sucesso!');
    window.location.href = 'carrinho.html';
}

function carregarListaProdutos() {
    var produtos = obterProdutos();

    var listaProdutos = document.getElementById('listaProdutos');
    listaProdutos.innerHTML = '';

    produtos.forEach(function(produto) {
        var row = document.createElement('tr');
        row.innerHTML = `
            <td>${produto.nome}</td>
            <td>${produto.descricao}</td>
            <td>R$ ${produto.valorUnitario.toFixed(2)}</td>
            <td>${produto.qtdEstoque}</td>
            <td><img src="ado4imgs/imgs/${produto.nomeArquivoImgProduto}" alt="${produto.nome}" width="100"></td>
            <td><button onclick="adicionarAoCarrinho(${produto.idProduto})">Adicionar ao Carrinho</button></td>
        `;
        listaProdutos.appendChild(row);
    });
}

function carregarOpcoesProdutos() {
    var produtos = obterProdutos();

    var selectProdutos = document.getElementById('produtos');
    produtos.forEach(function(produto) {
        var option = document.createElement('option');
        option.text = produto.nome;
        option.value = produto.idProduto;
        selectProdutos.appendChild(option);
    });
}

function obterProdutos() {
    return JSON.parse(localStorage.getItem('produtos')) || [];
}

window.onload = function() {
    carregarDadosCliente();
    carregarListaProdutos();
    carregarOpcoesProdutos();
};

function adicionarProdutosIniciais() {
    var produtos = [
        { 
            idProduto: 1,
            nome: 'iPhone 15 Pro Max',
            descricao: 'Smartphone Apple com 256GB',
            valorUnitario: 5999.99,
            qtdEstoque: 16,
            urlImgProduto: 'iphone15PM',
            nomeArquivoImgProduto: 'iphone15PM.png'
        },
        { 
            idProduto: 2,
            nome: 'Norisk Soul Grand Prix Italy',
            descricao: 'Capacete',
            valorUnitario: 849.90,
            qtdEstoque: 9,
            urlImgProduto: 'capacete',
            nomeArquivoImgProduto: 'capacete.png'
        },
        { 
            idProduto: 3,
            nome: 'Luva de Boxe e Muay Thai Everlast Core 2',
            descricao: 'Luva de boxe',
            valorUnitario: 149.99,
            qtdEstoque: 6,
            urlImgProduto: 'luva',
            nomeArquivoImgProduto: 'luva.png'
        },
        { 
            idProduto: 4,
            nome: 'Tênis Nike Air Jordan 1 Acclimate Chocolate WMNS',
            descricao: 'Tênis',
            valorUnitario:  2159.99,
            qtdEstoque: 10,
            urlImgProduto: 'tenis',
            nomeArquivoImgProduto: 'tenis.png'
        }
    ];

    localStorage.setItem('produtos', JSON.stringify(produtos));
}
