class Cliente {
    constructor(email, senha, nome, avatar) {
        this.email = email;
        this.senha = senha;
        this.nome = nome;
        this.avatar = avatar;
    }
}

function obterClientes() {
    return JSON.parse(localStorage.getItem('LoginCliente')) || [];
}

function salvarClientes(clientes) {
    localStorage.setItem('LoginCliente', JSON.stringify(clientes));
}

function cadastrarCliente(email, senha, nome, avatar) {
    const clientes = obterClientes();
    if (clientes.some(cliente => cliente.email === email)) {
        alert('Este e-mail já está cadastrado. Por favor, use outro e-mail.');
    } else {
        const novoCliente = new Cliente(email, senha, nome, avatar);
        clientes.push(novoCliente);
        salvarClientes(clientes);
        alert('Cadastro realizado com sucesso!');
    }
}

function fazerLogin(email, senha) {
    const clientes = obterClientes();
    const clienteLogado = clientes.find(cliente => cliente.email === email && cliente.senha === senha);
    if (clienteLogado) {
        alert(`Login bem-sucedido! Bem-vindo, ${clienteLogado.nome}`);
        localStorage.setItem('clienteLogado', JSON.stringify(clienteLogado));
        redirecionarVitrineCompleta();
    } else {
        alert('Email ou senha incorretos. Por favor, tente novamente.');
    }
}

function redirecionarVitrineCompleta() {
    window.location.href = 'vitrineCompleta.html';
}

function redirecionarVitrineParcial() {
    window.location.href = 'vitrineParcial.html';
}

document.getElementById('cadastroForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const nome = document.getElementById('nomeCadastro').value;
    const email = document.getElementById('emailCadastro').value;
    const senha = document.getElementById('senhaCadastro').value;
    const avatar = document.getElementById('avatar').files[0];
    cadastrarCliente(email, senha, nome, avatar);
});

document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const email = document.getElementById('email').value;
    const senha = document.getElementById('password').value;
    fazerLogin(email, senha);
});
