function carregarDadosCliente() {
    var cliente = JSON.parse(localStorage.getItem('clienteLogado'));
    if (cliente) {
        document.getElementById('avatarCliente').src = cliente.urlAvatarCliente;
        document.getElementById('nomeCliente').textContent = cliente.nomeCliente;
    } else {
        window.location.href = 'login.html';
    }
}

function adicionarAoCarrinho(idProduto) {
    var quantidade = parseInt(prompt('Digite a quantidade desejada:'));
    
    if (!quantidade || quantidade <= 0) {
        alert('Por favor, insira uma quantidade válida.');
        return;
    }

    var produtos = obterProdutos();
    var produtoSelecionado = produtos.find(function(produto) {
        return produto.idProduto === idProduto;
    });

    if (!produtoSelecionado) {
        alert('Produto não encontrado.');
        return;
    }

    if (quantidade > produtoSelecionado.qtdEstoque) {
        alert('Desculpe, não há estoque suficiente para essa quantidade.');
        return;
    }

    var carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
    var itemCarrinho = carrinho.find(function(item) {
        return item.idProduto === idProduto;
    });

    if (itemCarrinho) {
        itemCarrinho.quantidade += quantidade;
    } else {
        carrinho.push({
            idProduto: produtoSelecionado.idProduto,
            nome: produtoSelecionado.nome,
            valorUnitario: produtoSelecionado.valorUnitario,
            quantidade: quantidade
        });
    }

    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    alert('Produto adicionado ao carrinho com sucesso!');
}

function carregarItensCarrinho() {
    var carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];

    var listaCarrinho = document.getElementById('listaCarrinho');
    listaCarrinho.innerHTML = '';
    var valorTotalCompra = 0;

    carrinho.forEach(function(item, index) {
        var row = document.createElement('tr');
        var valorTotal = item.valorUnitario * item.quantidade;
        valorTotalCompra += valorTotal;
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${item.nome}</td>
            <td>${item.quantidade}</td>
            <td>R$ ${item.valorUnitario.toFixed(2)}</td>
            <td>R$ ${valorTotal.toFixed(2)}</td>
            <td><button onclick="removerItem(${index})">Remover</button></td>
        `;
        listaCarrinho.appendChild(row);
    });

    document.getElementById('valorTotalCompra').textContent = valorTotalCompra.toFixed(2);
}

function obterProdutos() {
    return JSON.parse(localStorage.getItem('produtos')) || [];
}

function removerItem(index) {
    var carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
    carrinho.splice(index, 1);
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    carregarItensCarrinho();
}

function finalizarCompra() {
    var numeroCartao = prompt('Digite o número do cartão de crédito:');
    var senhaCartao = prompt('Digite a senha do cartão de crédito:');
    if (numeroCartao && senhaCartao) {
        alert('Compra efetuada com sucesso!');
        localStorage.removeItem('carrinho');
        window.location.href = 'vitrineCompleta.html';
    } else {
        alert('Compra cancelada. Número do cartão e senha são necessários.');
    }
}

function voltarParaVitrine() {
    window.location.href = 'vitrineCompleta.html';
}

window.onload = function() {
    carregarDadosCliente();
    carregarItensCarrinho();
};
